touch /flag
chown root:root /flag
chmod 700 /flag
echo $DASFLAG > /flag
export DASFLAG=not_flag
chmod 400 /flag
rm /flag.sh