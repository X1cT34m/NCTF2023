<?php

if(isset($_GET['file']) && isset($_GET['filename'])){
    $file = $_GET['file'];
    $filename = $_GET['filename'];
    header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=$filename");
    readfile($file);
    exit();
}