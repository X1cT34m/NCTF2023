<?php
function security_validate()
{
    foreach ($_POST as $key => $value) {
        if (preg_match('/\r|\n/', $value)) {
            die("$key 不能包含换行符！");
        }
        if (strlen($value) > 114) {
            die("$key 不能超过114个字符！");
        }
    }
}
security_validate();
if (@$_POST['method'] && @$_POST['key'] && @$_POST['filename']) {
    if ($_POST['language'] !== 'PHP') {
        die("PHP是最好的语言");
    }
    $method = $_POST['method'];
    $key = $_POST['key'];
    putenv("METHOD=$method") or die("你的method太复杂了！");
    putenv("KEY=$key") or die("你的key太复杂了！");
    $status_code = -1;
    $filename = shell_exec("sh generate.sh");
    if (!$filename) {
        die("生成失败了！");
    }
    $filename = trim($filename);
    header("Location: download.php?file=$filename&filename={$_POST['filename']}");
    exit();
}
?>
<html>

<head>
    <title>Webshell生成器</title>
    <meta charset="utf-8">
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        form {
            margin: 50px auto;
            width: 400px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #666;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: none;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
    </style>
</head>

<body>
    <form action="index.php" method="post">
        <h1>Webshell生成器</h1>
        <label for="language">Webshell语言：</label>
        <select name="language" id="method">
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
            <option value="PHP">PHP</option>
        </select>
        <label for="method">请求方法：</label>
        <select name="method" id="method">
            <option value="POST">POST</option>
            <option value="GET">GET</option>
            <option value="REQUEST">REQUEST</option>
        </select>
        <label for="key">密钥：</label>
        <input name="key" type="text" value="114" pattern="[A-Za-z0-9]+" title="你的key太复杂了！简单点！o.O">
        <label for="filename">Webshell文件名称：</label>
        <input name="filename" type="text" value="webshell.php">
        <input type="submit" value="生成你的专属Webshell！">
    </form>
</body>