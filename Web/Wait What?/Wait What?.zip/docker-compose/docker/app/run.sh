#!/bin/sh


# 线上靶机每60秒重置一次。
if [ "$CTF_ENVIRONMENT" == "production" ]; then
    echo "线上环境，靶机每60秒重置一次。"
    while true
    do
        timeout 60 node app.js > /dev/null
    done
# 本地运行时取消靶机60秒重置限制。
else
    echo "本地环境，靶机不会每60秒重置。"
    node app.js
fi

