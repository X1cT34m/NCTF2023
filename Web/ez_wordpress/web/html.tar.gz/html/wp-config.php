<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'db' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'vPn0]P;!PGNpnz=0FBc07FP`VCr9J]SfOCuHgU~8bu:LUaS^{MI;K8>d@#!;]7C8' );
define( 'SECURE_AUTH_KEY',  '7zbv`@([F rK)Z1pVcQKCOxb<M%P*m5ZU2:C1SuZk9<Fn~~N<g.3QPg1MYDnlsgW' );
define( 'LOGGED_IN_KEY',    ';yq[(iB !xhlB}G9XJYs!zk:|HjNB/R^JD4PP$Q@:Ch#6#X4Z9=Q;dVjft-X``zI' );
define( 'NONCE_KEY',        '71KJAuw+5:DiCYu]15e$2O-%`g37um@RiUFwVKI3<IIrk4f#&iSmqF_Mf1*B[OI ' );
define( 'AUTH_SALT',        'vST1pX5Qq>2/SMeP`;SzJ]~-H*VO;Z@v[^|N2jFQr#LWp034(z?s/I>8,)r.uU+d' );
define( 'SECURE_AUTH_SALT', '{Wq->18y3Mk(bhX;@EsrdJ&IE;8@Bv|C|Nb&rVvfoNw  ;{k<9,)ORE#S-8mw)]t' );
define( 'LOGGED_IN_SALT',   'P.M)QP*m`~H]NB[lK~I5[!#4C^%F++P|$V2{G0ihhP!A3Hv5.FBV=HbeRwuwQRSG' );
define( 'NONCE_SALT',       '>8yR4W<K44F9LO^6FlW6|U5nb[O<+V]%GgVvW=2!x#I^ki{(HN9~;9aOZ,?O6!tf' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */
	
define( 'AUTOMATIC_UPDATER_DISABLED', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
